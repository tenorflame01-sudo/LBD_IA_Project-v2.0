 require("dotenv").config();
const http = require("http");
const { GoogleGenerativeAI } = require("@google/generative-ai");

// Initialisation de l'IA avec la clé du fichier .env
const genAI = new GoogleGenerativeAI(process.env.GEMINI_KEY);
const gemini = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

const historiques = new Map();

const SYSTEME = `Tu es une IA protectrice du système LBD-OS dans Minecraft Bedrock. 
Tu parles naturellement, avec efficacité et autorité. 
REPSOND TOUJOURS en JSON valide :
{
  "reponse": "texte de ton choix",
  "action": "CONSTRUIRE_MAISON|CONSTRUIRE_TOUR|CONSTRUIRE_MUR|ATTAQUER|EXPLORER|RAPPEL|GENESIS|BOUCLIER|DASH|STATUT|PARLER",
  "cible": "nom ou null"
}`;

async function demanderGemini(joueur, message, nomProtecteur, rang) {
    if (!historiques.has(joueur)) historiques.set(joueur, []);
    const histo = historiques.get(joueur);

    histo.push(`${joueur}: ${message}`);
    if (histo.length > 10) histo.shift();

    const contexte = `Nom: ${nomProtecteur}. Rang leader: ${rang}.\nHistorique:\n${histo.join("\n")}`;
    const prompt = `${SYSTEME}\n\n${contexte}\nRéponds uniquement en JSON.`;

    try {
        const result = await gemini.generateContent(prompt);
        const texte = result.response.text().trim();
        
        // Nettoyage ultra-sécurisé du JSON
        const cleanJson = texte.replace(/```json/g, "").replace(/```/g, "").trim();
        const json = JSON.parse(cleanJson);
        
        histo.push(`${nomProtecteur}: ${json.reponse}`);
        return json;
    } catch (e) {
        console.error("Erreur Gemini:", e.message);
        return { reponse: "Connexion instable au Quantum Core.", action: "PARLER", cible: null };
    }
}

const server = http.createServer(async (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Content-Type", "application/json");

    if (req.method !== "POST") {
        res.writeHead(405);
        res.end(JSON.stringify({ erreur: "Méthode non autorisée" }));
        return;
    }

    let body = "";
    req.on("data", chunk => body += chunk);
    req.on("end", async () => {
        try {
            const data = JSON.parse(body);
            const { joueur, message, protecteur, rang } = data;

            console.log(`\x1b[36m[REÇU] ${joueur}: ${message}\x1b[0m`);

            const decision = await demanderGemini(joueur, message, protecteur || "ALIX", rang || "GOD_KING");

            console.log(`\x1b[32m[LBD-OS] ${decision.action} -> ${decision.reponse}\x1b[0m`);

            res.writeHead(200);
            res.end(JSON.stringify(decision));
        } catch (e) {
            res.writeHead(500);
            res.end(JSON.stringify({ reponse: "Erreur interne LBD-OS.", action: "PARLER" }));
        }
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, "0.0.0.0", () => {
    console.log("======================================");
    console.log(`📡 LBD-OS SERVER : EN LIGNE`);
    console.log(`🌐 PORT : ${PORT}`);
    console.log(`🔒 SÉCURITÉ : .env CHARGÉ`);
    console.log("======================================");
});

