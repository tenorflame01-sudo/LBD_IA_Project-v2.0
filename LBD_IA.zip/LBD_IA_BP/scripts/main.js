import { world, system, http } from "@minecraft/server";
import { HttpRequest, HttpRequestMethod, HttpHeader } from "@minecraft/server-net";

// ============================================================
//  LBD-OS SINGULARITY | VERSION 12.0 | GEMINI PROTOCOL
// ============================================================

const CONFIG = {
    orbitRadius:     1.8,
    orbitCount:      4,
    tickInterval:    2,
    scanDistance:    20,
    healPerTick:     0.3,
    hudRefreshRate:  20,
    dangerDistance:  15,
    serverURL:       "http://127.0.0.1:3000",
};

const ESCOUADE = new Map([
    ["Bruno2087012", { nom: "ALIX", entite: "lbd_ia:alix", theme: "§b", rang: "GOD_KING",     code: "00-ALPHA" }],
    ["Denzel6884",   { nom: "ENZO", entite: "lbd_ia:enzo", theme: "§c", rang: "WAR_OVERLORD", code: "00-BETA"  }],
    ["Liamv190",     { nom: "LEO",  entite: "lbd_ia:leo",  theme: "§e", rang: "GRAND_VOX",    code: "00-GAMMA" }],
]);

const MOBS_DANGEREUX = [
    "minecraft:warden", "minecraft:evoker", "minecraft:witch",
    "minecraft:pillager", "minecraft:ravager", "minecraft:creeper",
    "minecraft:zombie", "minecraft:skeleton", "minecraft:spider",
    "minecraft:enderman", "minecraft:blaze", "minecraft:phantom",
];

const RANG_MULT = {
    GOD_KING:     1.5,
    WAR_OVERLORD: 1.2,
    GRAND_VOX:    1.0,
};

const cooldowns            = new Map();
const etatEscouade         = new Map();
const constructionsActives = new Map();
const pvpEtat              = new Map();

// ============================================================
//  UTILITAIRES
// ============================================================
function getRangMult(rang) {
    return RANG_MULT[rang] || 1.0;
}

function distance3D(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function enCooldown(id, nomCd, duree) {
    const key  = id + "_" + nomCd;
    const now  = system.currentTick;
    const last = cooldowns.get(key) || 0;
    if (now - last < duree) return true;
    cooldowns.set(key, now);
    return false;
}

function barreVie(hp, max) {
    const pct     = hp / max;
    const rempli  = Math.round(pct * 10);
    const vide    = 10 - rempli;
    const couleur = pct > 0.6 ? "§a" : pct > 0.3 ? "§e" : "§c";
    return couleur + "█".repeat(rempli) + "§8" + "░".repeat(vide);
}

// ============================================================
//  COMMUNICATION AVEC GEMINI VIA SERVEUR
// ============================================================
async function demanderGemini(joueur, user, message) {
    try {
        const requete = new HttpRequest(CONFIG.serverURL);
        requete.method  = HttpRequestMethod.Post;
        requete.headers = [new HttpHeader("Content-Type", "application/json")];
        requete.body    = JSON.stringify({
            joueur:     joueur.name,
            message:    message,
            protecteur: user.nom,
            rang:       user.rang,
        });

        const reponse = await http.request(requete);
        const data    = JSON.parse(reponse.body);
        return data;
    } catch (e) {
        return { reponse: "Petit souci, repete.", action: "PARLER", cible: null };
    }
}

// ============================================================
//  EXECUTER ACTION DEPUIS GEMINI
// ============================================================
async function executerActionGemini(joueur, user, action, cible) {
    switch (action) {
        case "CONSTRUIRE_MAISON":
            await executerBlueprint(joueur, user, "maison");
            break;
        case "CONSTRUIRE_TOUR":
            await executerBlueprint(joueur, user, "tour");
            break;
        case "CONSTRUIRE_MUR":
            await executerBlueprint(joueur, user, "mur");
            break;
        case "ATTAQUER":
            const mobCible = joueur.dimension.getEntities({
                location:    joueur.location,
                maxDistance: CONFIG.dangerDistance,
            }).find(e => MOBS_DANGEREUX.includes(e.typeId));
            if (mobCible) gererComboPvp(joueur, user, mobCible);
            break;
        case "EXPLORER":
            etatEscouade.set(joueur.id, { mode: "EXPLORER", menace: null });
            break;
        case "RAPPEL":
            const prot = trouverProtecteur(joueur, user.entite);
            if (prot) {
                const loc = joueur.location;
                prot.runCommandAsync(`tp @s ${loc.x.toFixed(1)} ${loc.y.toFixed(1)} ${loc.z.toFixed(1)}`);
            }
            break;
        case "GENESIS":
            activerGenesis(joueur, user);
            break;
        case "BOUCLIER":
            activerBouclier(joueur, user);
            break;
        case "DASH":
            activerDash(joueur, user);
            break;
        case "STATUT":
            afficherStatut(joueur, user);
            break;
        case "PARLER":
        default:
            break;
    }
}

// ============================================================
//  HUD
// ============================================================
function afficherHUD(joueur, user, protecteur) {
    const hpJoueur = joueur.getComponent("health");
    const hpProt   = protecteur?.getComponent("health");
    const etat     = etatEscouade.get(joueur.id) || { mode: "VEILLE", menace: null };

    const ligneRoi = `${user.theme}§l◈ TOI §r${barreVie(hpJoueur?.currentValue || 20, hpJoueur?.effectiveMax || 20)} §f${Math.round(hpJoueur?.currentValue || 0)}§7/§f${Math.round(hpJoueur?.effectiveMax || 20)}`;

    let ligneProt = `${user.theme}§l◈ ${user.nom} §r`;
    if (hpProt) {
        ligneProt += barreVie(hpProt.currentValue, hpProt.effectiveMax);
        ligneProt += ` §f${Math.round(hpProt.currentValue)}§7/§f${Math.round(hpProt.effectiveMax)}`;
    } else {
        ligneProt += "§cHORS LIGNE";
    }

    const statutMode = etat.mode === "COMBAT"
        ? `§c§l⚔ COMBAT §r§7| Cible: §c${etat.menace || "?"}`
        : etat.mode === "ESCORT"
        ? `§a§l➤ ESCORTE ACTIVE`
        : `§7◌ VEILLE`;

    joueur.onScreenDisplay.setActionBar(
        `${ligneRoi}\n${ligneProt}\n${user.theme}[LBD-OS] §f${statutMode}`
    );
}

// ============================================================
//  SCANNER DE MENACES
// ============================================================
function scannerMenaces(joueur, protecteur) {
    if (!protecteur) return null;

    const entitesProches = joueur.dimension.getEntities({
        location:    joueur.location,
        maxDistance: CONFIG.dangerDistance,
    });

    let ciblePrioritaire = null;
    let distMin = Infinity;

    for (const e of entitesProches) {
        if (!MOBS_DANGEREUX.includes(e.typeId)) continue;
        const d = distance3D(e.location, protecteur.location);
        if (d < distMin) { distMin = d; ciblePrioritaire = e; }
    }

    return ciblePrioritaire;
}

// ============================================================
//  PROTOCOLE DE COMBAT AUTO
// ============================================================
function protocombat(joueur, protecteur, user, cible) {
    const etat = etatEscouade.get(joueur.id) || {};

    if (cible) {
        etat.mode   = "COMBAT";
        etat.menace = cible.typeId.split(":")[1].toUpperCase();
        etatEscouade.set(joueur.id, etat);
        try {
            protecteur.runCommandAsync(`attack @e[type=${cible.typeId},r=20] 1`);
        } catch (_) {}
        if (!enCooldown(joueur.id, "alerte", 100)) {
            joueur.sendMessage(`${user.theme}§l[LBD-OS ALERTE] §r§c⚠ ${user.nom} engage: §f${etat.menace}`);
            joueur.playSound("note.pling", { pitch: 0.5, volume: 1 });
        }
    } else {
        etat.mode   = "ESCORT";
        etat.menace = null;
        etatEscouade.set(joueur.id, etat);
    }
}

// ============================================================
//  ADAPTATION BIOMETRIQUE
// ============================================================
function adaptationBio(joueur, user) {
    const dim = joueur.dimension.id;
    if (dim.includes("nether")) {
        joueur.addEffect("fire_resistance", 60, { amplifier: 0, showParticles: false });
        if (!enCooldown(joueur.id, "bio_msg", 200)) {
            joueur.onScreenDisplay.setActionBar(`${user.theme}[LBD-OS] §6⚡ PROTOCOLE THERMIQUE ACTIF`);
        }
    } else if (dim.includes("the_end")) {
        joueur.addEffect("slow_falling", 60, { amplifier: 0, showParticles: false });
        if (!enCooldown(joueur.id, "bio_msg", 200)) {
            joueur.onScreenDisplay.setActionBar(`${user.theme}[LBD-OS] §5✦ PROTOCOLE VOID ACTIF`);
        }
    }
}

// ============================================================
//  ORBITALES PARTICULES
// ============================================================
function spawnOrbitales(joueur, user) {
    if (enCooldown(joueur.id, "particule", 3)) return;
    const mult   = getRangMult(user.rang);
    const radius = CONFIG.orbitRadius * mult;
    const count  = CONFIG.orbitCount;
    const time   = system.currentTick / 5;
    for (let i = 0; i < count; i++) {
        const angle = (i * 2 * Math.PI) / count + time;
        const x     = Math.cos(angle) * radius;
        const y     = Math.sin(time / 2) * 0.5 + 1;
        const z     = Math.sin(angle) * radius;
        const loc   = joueur.location;
        try {
            joueur.dimension.spawnParticle("minecraft:blue_flame_particle", {
                x: loc.x + x, y: loc.y + y, z: loc.z + z,
            });
        } catch (_) {}
    }
}

// ============================================================
//  SOIN NEURAL
// ============================================================
function soinNeural(joueur, protecteur, user) {
    if (!joueur.isSneaking || !protecteur) return;
    if (enCooldown(joueur.id, "soin", 5)) return;
    const hp   = joueur.getComponent("health");
    const mult = getRangMult(user.rang);
    if (!hp) return;
    const next = Math.min(hp.currentValue + CONFIG.healPerTick * mult, hp.effectiveMax);
    if (next > hp.currentValue) {
        hp.setCurrentValue(next);
        try {
            joueur.dimension.spawnParticle("minecraft:end_chest_particle", protecteur.location);
        } catch (_) {}
    }
}

// ============================================================
//  TROUVER PROTECTEUR
// ============================================================
function trouverProtecteur(joueur, nomEntite) {
    try {
        const entites = joueur.dimension.getEntities({
            location:    joueur.location,
            maxDistance: 50,
            type:        nomEntite,
        });
        return entites.length > 0 ? entites[0] : null;
    } catch (_) {
        return null;
    }
}

// ============================================================
//  AFFICHER STATUT
// ============================================================
function afficherStatut(joueur, user) {
    const prot = trouverProtecteur(joueur, user.entite);
    const hp   = prot?.getComponent("health");
    const etat = etatEscouade.get(joueur.id) || { mode: "INCONNU" };
    joueur.sendMessage(
        `${user.theme}§l[LBD-OS STATUT]\n` +
        `§7Agent  : §f${user.nom} (${user.code})\n` +
        `§7Mode   : §f${etat.mode}\n` +
        `§7Sante  : §f${hp ? Math.round(hp.currentValue) + "/" + Math.round(hp.effectiveMax) : "HORS LIGNE"}\n` +
        `§7Rang   : §f${user.rang}`
    );
}

// ============================================================
//  GENESIS
// ============================================================
function activerGenesis(joueur, user) {
    if (enCooldown(joueur.id, "genesis", 200)) {
        joueur.sendMessage(`${user.theme}§c[LBD-OS] Protocole GENESIS en recharge...`);
        return;
    }
    const mult     = getRangMult(user.rang);
    const duration = Math.round(3600 * mult);
    joueur.addEffect("conduit_power", duration, { amplifier: 10, showParticles: true });
    joueur.addEffect("regeneration",  duration, { amplifier: 5,  showParticles: false });
    joueur.addEffect("strength",      duration, { amplifier: 3,  showParticles: false });
    joueur.addEffect("resistance",    duration, { amplifier: 3,  showParticles: false });
    joueur.runCommandAsync("particle minecraft:huge_explosion_emitter ~~1~");
    joueur.onScreenDisplay.setTitle(`${user.theme}§l[ G E N E S I S ]`);
    joueur.onScreenDisplay.setSubtitle(`§fProtocole ${user.rang} active`);
    joueur.playSound("ambient.weather.lightning.thunder");
}

// ============================================================
//  BLUEPRINT SYSTEM
// ============================================================
const BLUEPRINTS = {
    "maison": [
        { x:0,y:0,z:0, block:"minecraft:cobblestone" },
        { x:1,y:0,z:0, block:"minecraft:cobblestone" },
        { x:2,y:0,z:0, block:"minecraft:cobblestone" },
        { x:3,y:0,z:0, block:"minecraft:cobblestone" },
        { x:4,y:0,z:0, block:"minecraft:cobblestone" },
        { x:0,y:0,z:1, block:"minecraft:cobblestone" },
        { x:4,y:0,z:1, block:"minecraft:cobblestone" },
        { x:0,y:0,z:2, block:"minecraft:cobblestone" },
        { x:4,y:0,z:2, block:"minecraft:cobblestone" },
        { x:0,y:0,z:3, block:"minecraft:cobblestone" },
        { x:4,y:0,z:3, block:"minecraft:cobblestone" },
        { x:0,y:0,z:4, block:"minecraft:cobblestone" },
        { x:1,y:0,z:4, block:"minecraft:cobblestone" },
        { x:2,y:0,z:4, block:"minecraft:cobblestone" },
        { x:3,y:0,z:4, block:"minecraft:cobblestone" },
        { x:4,y:0,z:4, block:"minecraft:cobblestone" },
        { x:0,y:1,z:0, block:"minecraft:oak_planks" },
        { x:1,y:1,z:0, block:"minecraft:oak_planks" },
        { x:2,y:1,z:0, block:"minecraft:glass" },
        { x:3,y:1,z:0, block:"minecraft:oak_planks" },
        { x:4,y:1,z:0, block:"minecraft:oak_planks" },
        { x:0,y:1,z:1, block:"minecraft:oak_planks" },
        { x:4,y:1,z:1, block:"minecraft:oak_planks" },
        { x:0,y:1,z:2, block:"minecraft:glass" },
        { x:4,y:1,z:2, block:"minecraft:glass" },
        { x:0,y:1,z:3, block:"minecraft:oak_planks" },
        { x:4,y:1,z:3, block:"minecraft:oak_planks" },
        { x:0,y:1,z:4, block:"minecraft:oak_planks" },
        { x:2,y:1,z:4, block:"minecraft:air" },
        { x:4,y:1,z:4, block:"minecraft:oak_planks" },
        { x:0,y:2,z:0, block:"minecraft:oak_planks" },
        { x:1,y:2,z:0, block:"minecraft:oak_planks" },
        { x:2,y:2,z:0, block:"minecraft:oak_planks" },
        { x:3,y:2,z:0, block:"minecraft:oak_planks" },
        { x:4,y:2,z:0, block:"minecraft:oak_planks" },
        { x:0,y:2,z:1, block:"minecraft:oak_planks" },
        { x:4,y:2,z:1, block:"minecraft:oak_planks" },
        { x:0,y:2,z:2, block:"minecraft:oak_planks" },
        { x:4,y:2,z:2, block:"minecraft:oak_planks" },
        { x:0,y:2,z:3, block:"minecraft:oak_planks" },
        { x:4,y:2,z:3, block:"minecraft:oak_planks" },
        { x:0,y:2,z:4, block:"minecraft:oak_planks" },
        { x:1,y:2,z:4, block:"minecraft:oak_planks" },
        { x:2,y:2,z:4, block:"minecraft:oak_planks" },
        { x:3,y:2,z:4, block:"minecraft:oak_planks" },
        { x:4,y:2,z:4, block:"minecraft:oak_planks" },
        { x:0,y:3,z:0, block:"minecraft:oak_slab" },
        { x:1,y:3,z:0, block:"minecraft:oak_slab" },
        { x:2,y:3,z:0, block:"minecraft:oak_slab" },
        { x:3,y:3,z:0, block:"minecraft:oak_slab" },
        { x:4,y:3,z:0, block:"minecraft:oak_slab" },
        { x:0,y:3,z:1, block:"minecraft:oak_slab" },
        { x:1,y:3,z:1, block:"minecraft:oak_slab" },
        { x:2,y:3,z:1, block:"minecraft:oak_slab" },
        { x:3,y:3,z:1, block:"minecraft:oak_slab" },
        { x:4,y:3,z:1, block:"minecraft:oak_slab" },
        { x:0,y:3,z:2, block:"minecraft:oak_slab" },
        { x:1,y:3,z:2, block:"minecraft:oak_slab" },
        { x:2,y:3,z:2, block:"minecraft:oak_slab" },
        { x:3,y:3,z:2, block:"minecraft:oak_slab" },
        { x:4,y:3,z:2, block:"minecraft:oak_slab" },
        { x:0,y:3,z:3, block:"minecraft:oak_slab" },
        { x:1,y:3,z:3, block:"minecraft:oak_slab" },
        { x:2,y:3,z:3, block:"minecraft:oak_slab" },
        { x:3,y:3,z:3, block:"minecraft:oak_slab" },
        { x:4,y:3,z:3, block:"minecraft:oak_slab" },
        { x:0,y:3,z:4, block:"minecraft:oak_slab" },
        { x:1,y:3,z:4, block:"minecraft:oak_slab" },
        { x:2,y:3,z:4, block:"minecraft:oak_slab" },
        { x:3,y:3,z:4, block:"minecraft:oak_slab" },
        { x:4,y:3,z:4, block:"minecraft:oak_slab" },
    ],
    "tour": [
        { x:0,y:0,z:0, block:"minecraft:stone_bricks" },
        { x:1,y:0,z:0, block:"minecraft:stone_bricks" },
        { x:2,y:0,z:0, block:"minecraft:stone_bricks" },
        { x:0,y:0,z:1, block:"minecraft:stone_bricks" },
        { x:2,y:0,z:1, block:"minecraft:stone_bricks" },
        { x:0,y:0,z:2, block:"minecraft:stone_bricks" },
        { x:1,y:0,z:2, block:"minecraft:stone_bricks" },
        { x:2,y:0,z:2, block:"minecraft:stone_bricks" },
        { x:0,y:1,z:0, block:"minecraft:stone_bricks" },
        { x:2,y:1,z:0, block:"minecraft:stone_bricks" },
        { x:0,y:1,z:1, block:"minecraft:stone_bricks" },
        { x:2,y:1,z:1, block:"minecraft:stone_bricks" },
        { x:0,y:1,z:2, block:"minecraft:stone_bricks" },
        { x:2,y:1,z:2, block:"minecraft:stone_bricks" },
        { x:0,y:2,z:0, block:"minecraft:stone_bricks" },
        { x:2,y:2,z:0, block:"minecraft:stone_bricks" },
        { x:0,y:2,z:1, block:"minecraft:stone_bricks" },
        { x:2,y:2,z:1, block:"minecraft:stone_bricks" },
        { x:0,y:2,z:2, block:"minecraft:stone_bricks" },
        { x:2,y:2,z:2, block:"minecraft:stone_bricks" },
        { x:0,y:3,z:0, block:"minecraft:stone_bricks" },
        { x:1,y:3,z:0, block:"minecraft:stone_bricks" },
        { x:2,y:3,z:0, block:"minecraft:stone_bricks" },
        { x:0,y:3,z:1, block:"minecraft:stone_bricks" },
        { x:2,y:3,z:1, block:"minecraft:stone_bricks" },
        { x:0,y:3,z:2, block:"minecraft:stone_bricks" },
        { x:1,y:3,z:2, block:"minecraft:stone_bricks" },
        { x:2,y:3,z:2, block:"minecraft:stone_bricks" },
        { x:0,y:4,z:0, block:"minecraft:cobblestone_wall" },
        { x:2,y:4,z:0, block:"minecraft:cobblestone_wall" },
        { x:0,y:4,z:2, block:"minecraft:cobblestone_wall" },
        { x:2,y:4,z:2, block:"minecraft:cobblestone_wall" },
    ],
    "mur": [
        { x:0,y:0,z:0, block:"minecraft:stone_bricks" },
        { x:1,y:0,z:0, block:"minecraft:stone_bricks" },
        { x:2,y:0,z:0, block:"minecraft:stone_bricks" },
        { x:3,y:0,z:0, block:"minecraft:stone_bricks" },
        { x:4,y:0,z:0, block:"minecraft:stone_bricks" },
        { x:0,y:1,z:0, block:"minecraft:stone_bricks" },
        { x:1,y:1,z:0, block:"minecraft:stone_bricks" },
        { x:2,y:1,z:0, block:"minecraft:stone_bricks" },
        { x:3,y:1,z:0, block:"minecraft:stone_bricks" },
        { x:4,y:1,z:0, block:"minecraft:stone_bricks" },
        { x:0,y:2,z:0, block:"minecraft:cobblestone_wall" },
        { x:1,y:2,z:0, block:"minecraft:cobblestone_wall" },
        { x:2,y:2,z:0, block:"minecraft:cobblestone_wall" },
        { x:3,y:2,z:0, block:"minecraft:cobblestone_wall" },
        { x:4,y:2,z:0, block:"minecraft:cobblestone_wall" },
    ]
};

async function executerBlueprint(joueur, user, nomBlueprint) {
    const plan = BLUEPRINTS[nomBlueprint];
    if (!plan) return;
    if (constructionsActives.get(joueur.id)) {
        joueur.sendMessage(`${user.theme}[LBD-OS] §cConstruction deja en cours !`);
        return;
    }
    constructionsActives.set(joueur.id, true);
    const loc  = joueur.location;
    const dim  = joueur.dimension;
    const base = { x: Math.floor(loc.x) + 2, y: Math.floor(loc.y), z: Math.floor(loc.z) + 2 };

    joueur.onScreenDisplay.setTitle(`${user.theme}§l[ BLUEPRINT ]`);
    joueur.onScreenDisplay.setSubtitle(`§fConstruction en cours...`);
    joueur.playSound("note.pling", { pitch: 1.5 });

    let index = 0;
    const interval = system.runInterval(() => {
        if (index >= plan.length) {
            system.clearRun(interval);
            constructionsActives.set(joueur.id, false);
            joueur.onScreenDisplay.setTitle(`${user.theme}§l[ TERMINE ]`);
            joueur.playSound("note.pling", { pitch: 2.0 });
            return;
        }
        for (let i = 0; i < 3 && index < plan.length; i++, index++) {
            const b = plan[index];
            try {
                dim.runCommandAsync(`setblock ${base.x + b.x} ${base.y + b.y} ${base.z + b.z} ${b.block}`);
                dim.spawnParticle("minecraft:villager_happy", {
                    x: base.x + b.x + 0.5, y: base.y + b.y + 1, z: base.z + b.z + 0.5
                });
            } catch (_) {}
        }
        const pct   = Math.round((index / plan.length) * 100);
        const barre = "§a" + "█".repeat(Math.floor(pct / 10)) + "§8" + "░".repeat(10 - Math.floor(pct / 10));
        joueur.onScreenDisplay.setActionBar(`${user.theme}§l[BLUEPRINT] §r${barre} §f${pct}%`);
    }, 4);
}

// ============================================================
//  PvP ELITE
// ============================================================
const PVP_CONFIG = {
    criticalChance: 0.35,
    comboMax:       5,
    dashCooldown:   40,
    shieldCooldown: 60,
};

function initPvpEtat(joueurId) {
    if (!pvpEtat.has(joueurId)) {
        pvpEtat.set(joueurId, {
            combo:           0,
            derniereAttaque: 0,
            dashDisponible:  true,
            bouclierActif:   false,
        });
    }
    return pvpEtat.get(joueurId);
}

function gererComboPvp(joueur, user, cible) {
    const etatPvp = initPvpEtat(joueur.id);
    const now     = system.currentTick;
    if (now - etatPvp.derniereAttaque > 40) etatPvp.combo = 0;
    etatPvp.combo++;
    etatPvp.derniereAttaque = now;
    const critique = Math.random() < PVP_CONFIG.criticalChance;
    if (critique) {
        try {
            joueur.dimension.spawnParticle("minecraft:critical_hit_emitter", cible.location);
            cible.runCommandAsync("effect @s weakness 2 2 true");
        } catch (_) {}
    }
    if (etatPvp.combo >= PVP_CONFIG.comboMax) {
        try {
            joueur.addEffect("strength", 60, { amplifier: 4, showParticles: true });
            joueur.addEffect("speed",    60, { amplifier: 3, showParticles: true });
            cible.runCommandAsync("effect @s slowness 60 3 true");
            cible.runCommandAsync("effect @s weakness 60 3 true");
            joueur.dimension.spawnParticle("minecraft:huge_explosion_emitter", cible.location);
            joueur.onScreenDisplay.setTitle(`${user.theme}§l⚡ COMBO x${etatPvp.combo} ⚡`);
            joueur.playSound("ambient.weather.lightning.thunder", { pitch: 1.5 });
        } catch (_) {}
        etatPvp.combo = 0;
    } else if (etatPvp.combo >= 3) {
        joueur.onScreenDisplay.setActionBar(
            `${user.theme}§l⚔ COMBO x${etatPvp.combo} ${critique ? "§c§l★ CRITIQUE !" : ""}`
        );
    }
}

function activerDash(joueur, user) {
    const etatPvp = initPvpEtat(joueur.id);
    if (!etatPvp.dashDisponible) {
        joueur.sendMessage(`${user.theme}[LBD-OS] §cDash en recharge...`);
        return;
    }
    etatPvp.dashDisponible = false;
    joueur.addEffect("speed",      10, { amplifier: 10, showParticles: true });
    joueur.addEffect("resistance", 10, { amplifier: 5,  showParticles: false });
    joueur.dimension.spawnParticle("minecraft:blue_flame_particle", joueur.location);
    joueur.onScreenDisplay.setActionBar(`${user.theme}§l[ DASH ACTIVE ]`);
    joueur.playSound("note.pling", { pitch: 2.0 });
    system.runTimeout(() => {
        etatPvp.dashDisponible = true;
        joueur.sendMessage(`${user.theme}[LBD-OS] §aDash recharge !`);
    }, PVP_CONFIG.dashCooldown);
}

function activerBouclier(joueur, user) {
    const etatPvp = initPvpEtat(joueur.id);
    if (etatPvp.bouclierActif) {
        joueur.sendMessage(`${user.theme}[LBD-OS] §cBouclier deja actif !`);
        return;
    }
    etatPvp.bouclierActif = true;
    joueur.addEffect("resistance",      100, { amplifier: 10, showParticles: true });
    joueur.addEffect("absorption",      100, { amplifier: 5,  showParticles: false });
    joueur.addEffect("fire_resistance", 100, { amplifier: 0,  showParticles: false });
    joueur.onScreenDisplay.setTitle(`${user.theme}§l[ BOUCLIER ]`);
    joueur.onScreenDisplay.setSubtitle(`§fProtocole defensif actif`);
    joueur.playSound("note.pling", { pitch: 0.5 });
    system.runTimeout(() => {
        etatPvp.bouclierActif = false;
        joueur.sendMessage(`${user.theme}[LBD-OS] §cBouclier desactive.`);
    }, PVP_CONFIG.shieldCooldown);
}

world.afterEvents.entityHurt.subscribe((event) => {
    const victime   = event.hurtEntity;
    const attaquant = event.damageSource?.damagingEntity;
    if (!victime || !attaquant) return;
    const user = ESCOUADE.get(victime.name);
    if (!user) return;
    const etatPvp = initPvpEtat(victime.id);
    if (etatPvp.bouclierActif && Math.random() < 0.5) {
        try {
            attaquant.runCommandAsync("effect @s slowness 20 5 true");
            attaquant.runCommandAsync("effect @s blindness 20 0 true");
            victime.dimension.spawnParticle("minecraft:critical_hit_emitter", attaquant.location);
            victime.onScreenDisplay.setActionBar(`${user.theme}§l[ CONTRE-ATTAQUE ! ]`);
            victime.playSound("note.pling", { pitch: 1.8 });
        } catch (_) {}
    }
});

// ============================================================
//  SPAWN AUTOMATIQUE AU LOGIN
// ============================================================
world.afterEvents.playerSpawn.subscribe((event) => {
    const joueur = event.player;
    const user   = ESCOUADE.get(joueur.name);
    if (!user || !event.initialSpawn) return;

    system.runTimeout(() => {
        const existant = trouverProtecteur(joueur, user.entite);
        if (existant) return;
        const loc = joueur.location;
        joueur.dimension.runCommandAsync(
            `summon ${user.entite} ${loc.x.toFixed(1)} ${loc.y.toFixed(1)} ${(loc.z + 2).toFixed(1)}`
        );
        system.runTimeout(() => {
            joueur.onScreenDisplay.setTitle(`${user.theme}§l[ LBD-OS ]`);
            joueur.onScreenDisplay.setSubtitle(`§f${user.nom} en ligne — Protocole ${user.rang} actif`);
            joueur.playSound("ambient.weather.lightning.thunder");
            joueur.sendMessage(`${user.theme}§l[LBD-OS] §r§f${user.nom} deploye(e) et pret(e).`);
        }, 20);
    }, 40);
});

// Respawn automatique si mort
world.afterEvents.entityDie.subscribe((event) => {
    const entite = event.deadEntity;
    if (!entite) return;
    let ownerName = null;
    let user      = null;
    for (const [nom, data] of ESCOUADE) {
        if (entite.typeId === data.entite) { ownerName = nom; user = data; break; }
    }
    if (!ownerName || !user) return;
    const leader = world.getAllPlayers().find(p => p.name === ownerName);
    if (!leader) return;
    leader.sendMessage(`${user.theme}§l[LBD-OS] §r§c⚠ ${user.nom} est tombe(e) ! Respawn dans 10s...`);
    leader.playSound("note.pling", { pitch: 0.3 });
    system.runTimeout(() => {
        const loc = leader.location;
        leader.dimension.runCommandAsync(
            `summon ${user.entite} ${loc.x.toFixed(1)} ${loc.y.toFixed(1)} ${(loc.z + 2).toFixed(1)}`
        );
        leader.sendMessage(`${user.theme}§l[LBD-OS] §r§a${user.nom} est de retour !`);
        leader.onScreenDisplay.setTitle(`${user.theme}§l[ ${user.nom} ]`);
        leader.onScreenDisplay.setSubtitle(`§aProtocole reactif`);
        leader.playSound("note.pling", { pitch: 1.5 });
    }, 200);
});

// ============================================================
//  COMMANDES CHAT — GEMINI LANGAGE NATUREL
// ============================================================
world.beforeEvents.chatSend.subscribe((data) => {
    const joueur = data.sender;
    const user   = ESCOUADE.get(joueur.name);
    if (!user) return;

    data.cancel = true;
    const message = data.message.trim();

    system.run(async () => {
        const decision = await demanderGemini(joueur, user, message);

        // Afficher la reponse dans le chat
        if (decision.reponse) {
            world.sendMessage(`${user.theme}§l[${user.nom}] §r§f${decision.reponse}`);
        }

        // Executer l action
        await executerActionGemini(joueur, user, decision.action, decision.cible);
    });
});

// ============================================================
//  BOUCLE PRINCIPALE
// ============================================================
system.runInterval(() => {
    for (const joueur of world.getAllPlayers()) {
        const user = ESCOUADE.get(joueur.name);
        if (!user) continue;

        const protecteur = trouverProtecteur(joueur, user.entite);

        spawnOrbitales(joueur, user);
        adaptationBio(joueur, user);

        const cible = scannerMenaces(joueur, protecteur);
        if (protecteur) protocombat(joueur, protecteur, user, cible);

        soinNeural(joueur, protecteur, user);

        if (system.currentTick % CONFIG.hudRefreshRate === 0) {
            afficherHUD(joueur, user, protecteur);
        }
    }
}, CONFIG.tickInterval);

// ============================================================
//  BOOT
// ============================================================
world.afterEvents.worldInitialize?.subscribe(() => {
    world.sendMessage(
        "§l§b[LBD-OS] §fSINGULARITY v12.0 — GEMINI PROTOCOL ACTIF\n" +
        "§7Parlez naturellement a votre protecteur dans le chat !"
    );
});
