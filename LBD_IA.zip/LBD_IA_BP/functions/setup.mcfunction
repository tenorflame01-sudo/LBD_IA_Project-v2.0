# ============================================================
#  LBD-OS SINGULARITY v11.0 — SETUP PROTOCOL
#  Tapez : /function setup pour initialiser le systeme
# ============================================================

# --- NETTOYAGE --- Supprimer les anciens protecteurs
kill @e[type=lbd_ia:alix]
kill @e[type=lbd_ia:enzo]
kill @e[type=lbd_ia:leo]

# --- SPAWN ALIX pour Bruno2087012 ---
execute as @a[name=Bruno2087012] at @s run summon lbd_ia:alix ~ ~ ~2
execute as @a[name=Bruno2087012] at @s run title @s title §b§l[ LBD-OS ]
execute as @a[name=Bruno2087012] at @s run title @s subtitle §fALIX initialisee — Protocole GOD_KING actif
execute as @a[name=Bruno2087012] at @s run playsound ambient.weather.lightning.thunder @s

# --- SPAWN ENZO pour Denzel6884 ---
execute as @a[name=Denzel6884] at @s run summon lbd_ia:enzo ~ ~ ~2
execute as @a[name=Denzel6884] at @s run title @s title §c§l[ LBD-OS ]
execute as @a[name=Denzel6884] at @s run title @s subtitle §fENZO initialise — Protocole WAR_OVERLORD actif
execute as @a[name=Denzel6884] at @s run playsound ambient.weather.lightning.thunder @s

# --- SPAWN LEO pour Liamv190 ---
execute as @a[name=Liamv190] at @s run summon lbd_ia:leo ~ ~ ~2
execute as @a[name=Liamv190] at @s run title @s title §e§l[ LBD-OS ]
execute as @a[name=Liamv190] at @s run title @s subtitle §fLEO initialise — Protocole GRAND_VOX actif
execute as @a[name=Liamv190] at @s run playsound ambient.weather.lightning.thunder @s

# --- EFFETS DE BASE pour tous les leaders ---
effect @a[name=Bruno2087012] resistance 999999 2 true
effect @a[name=Bruno2087012] night_vision 999999 0 true
effect @a[name=Denzel6884] resistance 999999 1 true
effect @a[name=Denzel6884] night_vision 999999 0 true
effect @a[name=Liamv190] resistance 999999 1 true
effect @a[name=Liamv190] night_vision 999999 0 true

# --- TAGS D'IDENTIFICATION ---
tag @a[name=Bruno2087012] add LBD_ROI
tag @a[name=Denzel6884] add LBD_GENERAL
tag @a[name=Liamv190] add LBD_GENERAL

# --- MESSAGE GLOBAL ---
tellraw @a {"rawtext":[{"text":"§l§b[LBD-OS] §r§fSINGULARITY v11.0 — Escouade deployee. Protocole de protection HARDCORE actif."}]}
